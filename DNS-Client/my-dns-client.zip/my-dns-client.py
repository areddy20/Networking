#!/usr/bin/env python3

import sys
import socket
from dnslib import DNSRecord, A

def dns_query(host_name, query_type):
    query = DNSRecord.question(host_name, query_type)
    return query.pack()

def send_query(query_message, server_address):
    # Create a  socket using UDP protocal
    dns_client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # Send the query message to the server
    dns_client_socket.sendto(query_message, server_address)

    return dns_client_socket

def receive_response(client_socket):
    try:
        
        client_socket.settimeout(5) # Set  timeout = 5 seconds
        response_message, server_address = client_socket.recvfrom(4096)
        return response_message

    except socket.timeout:
        return None

    finally:
        client_socket.settimeout(None) # Reset socket timeout to default

def process_response(response_message):
    
    response = DNSRecord.parse(response_message) # Parse the response from DNS server

    
    print("\nHeader:")
    header = response.header
    print("header.ID =", header.id)
    print("header.QR =", header.qr)
    print("header.OPCODE =", header.opcode)
    print("header.AA =", header.aa)
    print("header.TC =", header.tc)
    print("header.RD =", header.rd)
    print("header.RA =", header.ra)
    print("header.Z =", header.z)
    print("header.RCODE =", header.rcode)
    print("header.QDCOUNT =", header.q)
    print("header.ANCOUNT =", header.a)
    print("header.NSCOUNT =", len(response.auth))
    print("header.ARCOUNT =", len(response.ar))

   
    print("\nQuestion:")
    for question in response.questions:
        print("question.QNAME =", question.qname)
        print("question.QTYPE =", question.qtype)
        print("question.QCLASS =", question.qclass)

   
    print("\nAnswer:")
    for answer in response.rr:
        print("answer.NAME =", answer.rname)
        print("answer.TYPE =", answer.rtype)
        print("answer.CLASS =", answer.rclass)
        print("answer.TTL =", answer.ttl)
        if isinstance(answer.rdata, A):
            rdata_str = str(answer.rdata)
            print("answer.RDLENGTH =", len(rdata_str))
            print("answer.RDATA =", rdata_str)
        print("...................................... ")
        

    
    print("\nAuthority:")
    for authority in response.auth:
        print(authority)

    
    print("\nAdditional:")
    for additional in response.ar:
        print(additional)


## Starting point of the program

## Check if hostname is passed as an argument

if len(sys.argv) < 2:
    print("Usage: python my-dns-client.py <host-name>")
    sys.exit(1)


# Get the host name from command line 
host_name = sys.argv[1]
query_type = "A"  # Only interested in A record



print("Preparing DNS query...")
query_message = dns_query(host_name, query_type)

# Google Public DNS Server details and port
server_address = ('8.8.8.8', 53)  

print("Contacting DNS server...")
print("Sending DNS query...")

RETRIES_COUNTER = 0
MAXIMUM_RETRIES = 3
RESPONSE_MESSAGE = None

# Retry loop with timeout-based retry mechanism

while RETRIES_COUNTER < MAXIMUM_RETRIES:
    RETRY_ATTEMPT_COUNTER = RETRIES_COUNTER + 1
    print(f"DNS query attempt {RETRY_ATTEMPT_COUNTER} of {MAXIMUM_RETRIES}")
    print("Sending DNS query...")

    # Send the DNS query
    client_socket = send_query(query_message, server_address)

    # Receive and process the DNS response
    RESPONSE_MESSAGE = receive_response(client_socket)

    if RESPONSE_MESSAGE is not None:
        print("DNS response received")
        print("Processing DNS response...")
        break  # Break while loop if a DNS server responded and received response

    print("Timeout. Retrying...")
    RETRIES_COUNTER += 1

# Check if there is a response from DNS Server, otherwise, display appropriate message

if RESPONSE_MESSAGE is None:
    print("No Response from DNS server and query failed. Maximum retries exceeded.")
else:
    process_response(RESPONSE_MESSAGE)

