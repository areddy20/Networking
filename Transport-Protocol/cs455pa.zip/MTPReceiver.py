import socket
import sys
import struct
import zlib
import argparse
import logging

MAX_PACKET_SIZE = 1472
DATA_PACKET_TYPE = 0
ACK_PACKET_TYPE = 1


MTP_PACKET_STRUCT = struct.Struct('!I I I I')   # Structure of the MTP packet

# Define function to calculate the CRC32 checksum
def calculate_checksum(data):
    checksum = zlib.crc32(data)
    return checksum & 0xffffffff

def receive_file(receiver_port, output_file, log_file):
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # First create the UDP socket
    sock.bind(('', receiver_port))

    #
    expected_seq_num = 0

    try:
        with open(log_file, 'w') as log:
            while True:

                
                data, address = sock.recvfrom(MAX_PACKET_SIZE)   # Receiving  packets from the sender on the same port
                packet_type, seq_num, data_length, checksum = MTP_PACKET_STRUCT.unpack(data[:MTP_PACKET_STRUCT.size])
                received_data = data[MTP_PACKET_STRUCT.size:]

                # check to see  the checksum of the received packet is good
                if calculate_checksum(received_data) == checksum:
                    if packet_type == DATA_PACKET_TYPE and seq_num == expected_seq_num:
                         
                        with open(output_file, 'ab') as file:
                            file.write(received_data)

                        log_line = f"Packet received; type=DATA; seqNum={seq_num}; length={data_length}; checksum_in_packet={checksum:x}; checksum_calculated={checksum:x}; status=NOT_CORRUPT"
                        log.write(log_line + "\n")

                        ack_packet = MTP_PACKET_STRUCT.pack(ACK_PACKET_TYPE, seq_num, 0, 0)
                        sock.sendto(ack_packet, address)

                        log_line = f"Packet sent; type=ACK; seqNum={seq_num}; length=0"
                        log.write(log_line + "\n")

                        expected_seq_num += 1

                    elif packet_type == DATA_PACKET_TYPE and seq_num < expected_seq_num:
                        
                        ack_packet = MTP_PACKET_STRUCT.pack(ACK_PACKET_TYPE, seq_num, 0, 0)  # If any duplicate packets found , discard them and send ACK
                        sock.sendto(ack_packet, address)

                        log_line = f"Packet received; type=DATA; seqNum={seq_num}; length={data_length}; checksum_in_packet={checksum:x}; checksum_calculated={checksum:x}; status=DUP"
                        log.write(log_line + "\n")

                    else:
                       
                        ack_packet = MTP_PACKET_STRUCT.pack(ACK_PACKET_TYPE, expected_seq_num - 1, 0, 0)    # Check any Out-of-order packets, discard and send ACK for the last in-order packet
                        sock.sendto(ack_packet, address)

                        log_line = f"Packet received; type=DATA; seqNum={seq_num}; length={data_length}; checksum_in_packet={checksum:x}; checksum_calculated={checksum:x}; status=OUT_OF_ORDER_PACKET"
                        log.write(log_line + "\n")

                else:
                    
                    ack_packet = MTP_PACKET_STRUCT.pack(ACK_PACKET_TYPE, expected_seq_num - 1, 0, 0)   # Check any Corrupt packets, discard and send ACK for the last in-order packet
                    sock.sendto(ack_packet, address)

                    log_line = f"Packet received; type=DATA; seqNum={seq_num}; length={data_length}; checksum_in_packet={checksum:x}; checksum_calculated={checksum:x}; status=CORRUPT"
                    log.write(log_line + "\n")

    except KeyboardInterrupt:
        logging.info("\nExiting the program...")

    # Close the socket
    sock.close()

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('receiver_port', type=int, help='Receiver port number')
    parser.add_argument('output_file', help='Output file path')
    parser.add_argument('log_file', help='Log file path')
    return parser.parse_args()

def main():
    args = parse_arguments()

    # logging happens here
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    receive_file(args.receiver_port, args.output_file, args.log_file)

if __name__ == '__main__':
    main()


