Instructions to execute:

On sender Linux server:
----------------------
python3 MTPSender.py 192.168.1.236 51090 100 1MB.txt sender-log-file.txt

On Receiver Linux server:
------------------------
python3 MTPReceiver.py 51090 output-file.txt receiver-log-file.txt



Output as follows:
------------------

On Sender Linux Server:
-----------------------

$ls -altrh
total 1.6M
drwxr-xr-x. 5 root root  146 Jun 20 22:23 ..
-rw-r--r--. 1 root root 4.7K Jun 20 22:24 MTPSender.py
-rw-r--r--. 1 root root 977K Jun 20 22:24 1MB.txt
-rw-r--r--. 1 root root 555K Jun 20 22:56 sender-log-file.txt
drwxr-xr-x. 2 root root   68 Jun 20 22:56 .
$

$sha1sum 1MB.txt
55a944d8c6104168f0b4b9d5585af4d7184313c1  1MB.txt


On Receiver Linux Server:
---------------------------

$ls -altrh
total 1.1M
drwxr-xr-x 5 root root  172 Jun 20 22:30 ..
-rw-r--r-- 1 root root 4.2K Jun 20 22:31 MTPReceiver.py
drwxr-xr-x 2 root root   80 Jun 20 22:56 .
-rw-r--r-- 1 root root 113K Jun 20 22:56 receiver-log-file.txt
-rw-r--r-- 1 root root 977K Jun 20 22:56 output-file.txt
$

$sha1sum output-file.txt
55a944d8c6104168f0b4b9d5585af4d7184313c1  output-file.txt



Verified checksum and both 1MB.txt and output-file.txt came out same as shown above