import socket
import sys
import struct
import zlib
import time
import argparse
import logging

MAX_PACKET_SIZE = 1472
DATA_PACKET_TYPE = 0
ACK_PACKET_TYPE = 1
TIMEOUT = 0.5  


MTP_PACKET_STRUCT = struct.Struct('!IIII')   #  Structure of the packet

# Checksum function for calculating the CRC32 checksum
def calculate_checksum(data):
    checksum = zlib.crc32(data)
    return checksum & 0xffffffff

def send_file(receiver_ip, receiver_port, window_size, input_file, log_file):
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)   # First create the  UDP socket
    sock.settimeout(TIMEOUT)

    
    with open(input_file, 'rb') as file:    # Opem and Read the input file provided as a parameter
        file_data = file.read()

    
    data_chunks = [file_data[i:i + MAX_PACKET_SIZE - 16] for i in range(0, len(file_data), MAX_PACKET_SIZE - 16)]  # Splitting  the input file data into  chunks

     
    base = 0
    next_seq_num = 0
    window = []
    log_lines = []

    logging.info("Sending file: %s", input_file)
    logging.info("Window size: %d", window_size)

    try:
        while base < len(data_chunks):
            # Sending  packets in the specified window
            while next_seq_num < base + window_size and next_seq_num < len(data_chunks):
                seq_num = next_seq_num % (2 ** 32)
                data = data_chunks[next_seq_num]
                data_length = len(data)
                checksum = calculate_checksum(data)

                packet = MTP_PACKET_STRUCT.pack(DATA_PACKET_TYPE, seq_num, data_length, checksum)
                packet += data

                sock.sendto(packet, (receiver_ip, receiver_port))

                log_line = f"Packet sent; type=DATA; seqNum={seq_num}; length={data_length}; checksum={checksum:x}"
                log_lines.append(log_line)

                window.append(seq_num)
                next_seq_num += 1

            try:
                # while infinite loop to Receive ACKs till timeout 
                while True:
                    data, address = sock.recvfrom(MAX_PACKET_SIZE)
                    ack_packet = MTP_PACKET_STRUCT.unpack(data)
                    ack_type = ack_packet[0]
                    ack_seq_num = ack_packet[1]

                    if ack_type == ACK_PACKET_TYPE and ack_seq_num in window:
                        window.remove(ack_seq_num)
                        base += 1

                        log_line = f"Packet received; type=ACK; seqNum={ack_seq_num}; length=0"
                        log_lines.append(log_line)
                    else:
                        log_line = f"Ignored packet; type={ack_type}; seqNum={ack_seq_num}"
                        log_lines.append(log_line)

            except socket.timeout:
                #   retransmit packets in the window once timeout reaches
                for seq_num in window:
                    data = data_chunks[seq_num]
                    data_length = len(data)
                    checksum = calculate_checksum(data)

                    packet = MTP_PACKET_STRUCT.pack(DATA_PACKET_TYPE, seq_num, data_length, checksum)
                    packet += data

                    sock.sendto(packet, (receiver_ip, receiver_port))

                    log_line = f"Timeout for packet; seqNum={seq_num}"
                    log_lines.append(log_line)

            # Write and Update the window state in the log
            window_state = ' '.join([f"{seq_num}({0 if seq_num in window else 1})" for seq_num in range(base, base + window_size)])
            log_line = f"Updating window; Window state: [{window_state}]"
            log_lines.append(log_line)

            time.sleep(0.1)  # Add a small pause in case any network flooding happens. 

    except KeyboardInterrupt:
        logging.info("\nExiting the program...")

   
    #  logging happens here
    with open(log_file, 'w') as file:             
        file.write('\n'.join(log_lines))

    
    sock.close()  # Close the socket

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('receiver_ip', help='Receiver IP address')
    parser.add_argument('receiver_port', type=int, help='Receiver port number')
    parser.add_argument('window_size', type=int, help='Window size')
    parser.add_argument('input_file', help='Input file path')
    parser.add_argument('log_file', help='Log file path')
    return parser.parse_args()

def main():
    args = parse_arguments()

     
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')    # Configure logging to log information

    send_file(args.receiver_ip, args.receiver_port, args.window_size, args.input_file, args.log_file)

if __name__ == '__main__':
    main()

